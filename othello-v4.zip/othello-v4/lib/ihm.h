/* ihm.h */

#ifndef INCL_IHM_H
#define INCL_IHM_H

#include <stdio.h>
#include "constantes.h"

void initOthellier(char othellier[TAILLE][TAILLE]);
void affichageOthellier(char othellier[TAILLE][TAILLE]);

#endif

