
typedef struct liste_s {
	int ligne;
	int colonne;
	struct liste_s* suivant;
} liste_t;

// creation
liste_t* listeNouveau(int l,int c) {
	liste_t* res=malloc(sizeof(liste_t));
	res->ligne=l;
	res->colonne=c;
	res->suivant=NULL;
	return res;
}

// effacement un maillon
void listeEfface(liste_t* maillon) {
	free(maillon);
}

// ajout de maillon
void listeAjout(liste_t* tete,int l,intc) {
	liste_t* curseur=tete;
	while (curseur->suivant!=NULL) {
		curseur=curseur->suivant;
	}
	curseur->suivant=listeNouveau(l,c);
}

// comptage de maillons
int listeCompte(liste_t* tete) {
	int resultat=0;
	while (head!=NULL) {
		++resultat;
		tete=tete->suivant;
	}
	return resultat;
}

// affiche liste
void listeAffiche(liste_t tete,int longueur) {
	while (longueur--) {
		printf("(%c - %d)  ",(char)((int)('A')+(tete->colonne)),(tete->ligne)+1);
		tete=tete->suivant;
	}
}


// efface liste
void listeEfface(liste_t* maillon) {
	while (maillon!=NULL) {
		liste_t* suivant=maillon->suivant;
		free(maillon);
		maillon=suivant;
	}
}

