/* constantes.c */


#include "constantes.h"

const char VIDE=' ';
const char NOIR='X';
const char BLANC='O';
const int TAILLE=8;


